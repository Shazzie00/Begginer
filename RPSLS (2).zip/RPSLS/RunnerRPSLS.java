package ogunseye;

public class RunnerRPSLS {
    RPSLS Ogunseye;
    public static void main(String[] args) {
        RPSLS game = new RPSLS();
        game.playGame();




    }
}
