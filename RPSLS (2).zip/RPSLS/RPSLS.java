package ogunseye;

import java.util.Random;
import java.util.Scanner;

public class RPSLS {

    // weapon variables
    private static final int ROCK = 0;

    // this weapon variables is for the paper
    private static final int PAPER = 1;

    // this weapon variables is for scissors
    private static final int SCISSORS = 2;

    // this weapon variables is for lizard
    private static final int LIZARD = 3;

    // this weapon variables is for spock
    private static final int SPOCK = 4;

    // this variable represent player 1
    private static final int PLAYER1 = 1;

    // this variable represent player 2
    private static final int PLAYER2 = 2;

    // this variable represent tie and subracts -1
    private static final int TIE = -1;

    private int random;

    // Variables to control the player and selections
    private int consecutiveWinsPlayer1 = 0;
    private int consecutiveWinsPlayer2 = 0;
    private int consecutiveGoal;

    // Variables to keepts track of the matches
    private int totalMatches = 0;

    // These are the setter and getters
    public int getConsecutiveGoal() {
        return consecutiveGoal;}

    public int getConsecutiveWinsPlayer1() {
        return consecutiveWinsPlayer1;}

    public int getConsecutiveWinsPlayer2() {
        return consecutiveWinsPlayer2;}

    public void setConsecutiveGoal(int matches) {
        this.consecutiveGoal = matches;}

    private int randomWeapon() {
        return random = ((int) (Math.random() * 5));
    }

    // I used the switch method the weapon integers into a string when printed out
    public static String convert(int i) {
        switch (i) {
            case ROCK:
                return "Rock";
            case PAPER:
                return "Paper";
            case SCISSORS:
                return "Scissors";
            case LIZARD:
                return "Lizard";
            case SPOCK:
                return "Spock";
            default:
                return "Invalid";
        }
    }

    // This method is used to control the result and is basically shows the rules and how to get a point
    private int result(int playerOneSelection, int playerTwoSelection) {
        if (playerOneSelection == playerTwoSelection) {
            return TIE;}

        if (playerOneSelection == ROCK && playerTwoSelection == SCISSORS) {
            return PLAYER1;}
        else if (playerOneSelection == ROCK && playerTwoSelection == LIZARD) {
            return PLAYER1;}
        else if (playerOneSelection == PAPER && playerTwoSelection == ROCK) {
            return PLAYER1;}
        else if (playerOneSelection == PAPER && playerTwoSelection == SPOCK) {
            return PLAYER1;}
        else if (playerOneSelection == SCISSORS && playerTwoSelection == PAPER) {
            return PLAYER1;}
        else if (playerOneSelection == SCISSORS && playerTwoSelection == LIZARD) {
            return PLAYER1;}
        else if (playerOneSelection == LIZARD && playerTwoSelection == SPOCK) {
            return PLAYER1;}
        else if (playerOneSelection == LIZARD && playerTwoSelection == PAPER) {
            return PLAYER1;}
        else if (playerOneSelection == SPOCK && playerTwoSelection == SCISSORS) {
            return PLAYER1;}
        else if (playerOneSelection == SPOCK && playerTwoSelection == ROCK) {
            return PLAYER1;}
        else {
            return PLAYER2;}
    }

    // The playRound method tallies the point and is linked to the result method
    // I had used individual variables to keep track of the point sonce ot was easier and more understandable for me to
    // use in the code
    public void playRound(int playerOneSelection, int playerTwoSelection) {
        int roundResult = result(playerOneSelection, playerTwoSelection);

        if (roundResult == TIE) {
            consecutiveWinsPlayer1 = 0;
            consecutiveWinsPlayer2 = 0;
            System.out.println("It was a tie !");}
        else if (roundResult == PLAYER1) {
            consecutiveWinsPlayer1++;
            consecutiveWinsPlayer2 = 0;
            System.out.println("Player 1 is the winner!");}
        else if (roundResult == PLAYER2) {
            consecutiveWinsPlayer2++;
            consecutiveWinsPlayer1 = 0;
            System.out.println("Player 2 is the winner!");}


    }

    // The play game method is where everything is kept together and the main loop is kept.
    // In this method I total the matches and print out each of the computer player's result
    public void playGame() {
        Scanner user = new Scanner(System.in);
        System.out.print("""
                Welcome to the arena! Here you will witness two AI opponents locked in epic battle with\s
                Rock Paper Scissors Lizard and Spock until one participant wins a given number of matches in a row\s
                """);
        System.out.print("How many consecutive wins are needed for victory: ");
        consecutiveGoal = user.nextInt();

        while (consecutiveWinsPlayer1 < consecutiveGoal && consecutiveWinsPlayer2 < consecutiveGoal) {
            int player1Choice = randomWeapon();
            int player2Choice = randomWeapon();

            playRound(player1Choice, player2Choice);
            totalMatches++;

            System.out.format("%-30s%-15s%-10s%n", "Player 1 chooses: ", "Player 2 chooses:", "");

            System.out.format("%-30s%-15s%n", convert(player1Choice), convert(player2Choice));

            System.out.format("%-30s%-15s%-10s%n", "Player 1 score : ", "Player 2 score:", "");
            System.out.format("%-30s%-15s%n",  getConsecutiveWinsPlayer1() , getConsecutiveWinsPlayer2());
            System.out.println("---------------------------------------------------------------------------");
            if (getConsecutiveWinsPlayer1() == consecutiveGoal) {
                System.out.println("Player 1 wins after " + totalMatches + " matches");
            } else if (getConsecutiveWinsPlayer2() == consecutiveGoal) {
                System.out.println("Player 2 wins after " + totalMatches + " matches");
            }

        }
    }
}
